'use strict'

const jwt = require('jsonwebtoken');

module.exports={

    getJWT:function() {
        return 'kjdfsgkhjk5hjsdhdskjfh435h3k4j5hkj34h5khjsdfgj9953jk5hkj';
    },

    getPrt:function(){
        return 40100;
    },
    
    getDataBase:function() {
        return 'GeneralAdministration';
    },
    getCollUsers:function(){
        return 'users';
    },
    getCollCompanies:function(){
        return 'companies';
    }
};
