'use strict'

var db = require('../db');
var config = require('../config');
const response = require('../network/responses');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user');

// The auth() function verifies that the user, password and company parameters are passed 
// It is verified that the parameters match in the database 
function auth (req, res){

    if (!req.body.user || !req.body.password || !req.body.company) return response.incompleteData(req, res);

    let user = req.body.user;
    let company = req.body.company;

    _searchCompany(company)
        .then(
            result => {
                // result[0].db => Extract the name of the company database
                return  _searchUser(user, company, result[0].db)
            }, reason => {
                return Promise.reject(reason)
        })
        .then(
            result => {
                return _verifyUser(result, req.body.password)
            }, reason => {
                return Promise.reject(reason)
        })
        .then(
            result => {
                return response.success(req, res, result);
            }, reason => {
                return response.errorMessage(req, res, reason);
        });
}

// The _searchCompany() function receives as a parameter company of type string
// Verify that the company exists in the database
function _searchCompany(company){

    let DB = db.get().db(config.getDataBase()).collection(config.getCollCompanies());

    let search_company = {name: company};
    let filter_company = {_id:1, name:1, db:1, status:1,}

    const companyDB = new Promise((resolve, reject) => {
        DB.aggregate([{$match: search_company}, {$project: filter_company}]).toArray (function (err, result) {
            if (err){
                reject ("Search error.");
            }else {
                if (result.length === 0) reject ('The company does not exist.');
                resolve(result);
            }
        });
    });
    return companyDB;
}

// The _searchUser() function receives as a parameter user, company, database all of type string
// verify that the user exists and belongs to that company, if so, attach the name of the database 
function _searchUser(user, company, database){

    let DB = db.get().db(config.getDataBase()).collection(config.getCollUsers());

    let search = {$and: [{company: company}, {$or: [{identification_card: user}, {email: user}]}]}
    let filter = {_id: 0, name: 1, identification_card: 1, email: 1, password: 1, status: 1, profile: 1}

    const userDB = new Promise((resolve, reject) => {
        DB.aggregate([{$match: search }, {$project: filter}]).toArray(function (err, result) {
            if (err){
                reject ("Search error.");
            }else {
                if(result.length === 0){
                    reject('User does not exist.')
                }else{
                    result[0].database = database;
                    resolve(result[0]);
                }
            }
        });
    });
    return userDB;
}

// The _verifyUser() function receives as a parameter user object and password of type string
// if the user is active, check the password of the user object with which it was passed as a parameter
// if the password is correct, create a token for that user that lasts 16 hours
function _verifyUser(user, password){
    
    const verified_user = new Promise((resolve, reject) => {
        if (user.status == 1) {
            reject ("Account Inactive");                   
        }else if (user.status == 0) {

            if (bcrypt.compareSync(password, user.password)) {
                let payload = { userID: user.email, companyDB: user.database};
                let jwtUser = jwt.sign(payload,config.getJWT(),{expiresIn:'16h'});
                // Data for the frontend 
                let user_data ={
                    name: user.name,
                    email: user.email,
                    estado: user.status
                };

                resolve({token: jwtUser, datos: user_data})
            }else {
                reject ("Incorrect password");
            }
        }else {
            reject ("Blocked account");
        }
       
    });
    return verified_user;
}


// The register() function check if user exists or not
// if it does not exist create an account for that user 
function register(req, res){

    if (!req.body.email) return response.incompleteData(req, res);

    _searchUserEmail (req.body.email).then(result => {
        if (result === null){
            accountCreation (req.body, res);
        }else {
            if (result.status === 0) return response.accountError(req, res, 'Existing account.');
            return response.accountError(req, res, 'Account disabled.');
        }
    }, reason => {
        return response.errorMessage(req, res, reason);
    });
}

// Auxiliary function 
async function accountCreation(req, res){
    userCreation(req, res);
}

// The userCreation() function prepare the data to be inserted in a new user 
async function userCreation(req, res) {

    let ref = [
        "name",
        "email",
        "identification_card",
        "password",
        "company",
        "description"
    ]
    for (let i in ref){
        if (req[ref[i]] == undefined || req[ref[i]] == null) return response.incompleteData(req, res);
    }

    const current_date = new Date();
    current_date.setTime(current_date.getTime() - current_date.getTimezoneOffset() * 60 * 1000);
    const encrypted_key = await keyGenerator(req.password);

    let user = new User();
    user.setParameters('creation_date', current_date);
    user.setParameters('email', req.body.email);
    user.setParameters('password', encrypted_key);
    user.setParameters('company', req.body.company);
    user.setParameters('description', req.body.description);
    user.setParameters('identification_card', req.body.identification_card);
    user.setParameters('name', req.body.name);
    user.setParameters('perfil', req.body.perfil);

    var db = db.get().db(config.getDataBase()).collection(config.getCollUsers());

    db.insertOne(user, (err) => {
        return (err) ? response.error(req, res) : response.successMessage(req, res);
    });
}

// The _searchUserEmail() function receives as a parameter an email or identification_card of type string
// check if the user already exists in the database
function _searchUserEmail(parameter){

    var db = db.get().db(config.getDataBase()).collection(config.getCollUsers());

    var search= {$or: [{email: parameter}, {identification_card: parameter}]};

    const user = new Promise((resolve, reject) => {
        db.findOne(search, function (err, result) {
            if(err){
                reject({Mensaje:"User request error."});                
            }
                resolve(result);
            });
    });
    return user;
}

// The _searchUserEmail() function receives as a parameter a key of type string
// generate a key using the parameter that was passed 
function keyGenerator(key){
    var salt = bcrypt.genSaltSync(13);
    var hasht;

    const generated_key  = new Promise((resolve, reject) => {
        bcrypt.hash(key, salt, function(err, hash){
            if (err) throw (err);

            bcrypt.compare(key, hash, function(err, result) {
                if (err) throw (err);
                console.log(result);
                hasht = hash;
                resolve(hasht);
            });
        });

    });
    return generated_key;
}

module.exports = {
    auth,
    register
};
