'use strict'

var express = require('express');
var authentication = require('../controllers/authentication');
var router = express.Router();

// Routes for Authentication 
router.post('/auth', authentication.auth);
router.post('/register', authentication.register);

module.exports = router;