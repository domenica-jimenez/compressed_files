exports.success = function(req, res, data){
    res.status(200).send(data);
}

exports.successMessage = function(req, res){
    res.status(200).send({
        status: 200,
        error: 'Data created/update successfully.'
    });
}

exports.incompleteData = function(req, res){
    res.status(400).send({
        status: 400,
        error: 'Incomplete parameters.'
    });
} 

exports.error = function(req, res){
    res.status(500).send({
        status: 500,
        error: 'Request error.'
    });
}

exports.errorMessage = function(req, res, reason){
    res.status(500).send({
        status: 500,
        error: reason
    });
}

exports.accountError = function(req, res, message){
    res.status(202).send({
        status: 202,
        error: message
    });
}

