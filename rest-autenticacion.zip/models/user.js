var ObjectId = require('mongodb').ObjectID;

function User(){

        this._id = new ObjectId(),
        this.status = 0,
        this.creation_date = new Date(),
        this.email = "",
        this.password = "",
        this.company =  "",
        this.description = "",
        this.identification_card = "",
        this.name = "",
        this.profile =  "User"


    // Setter for data changes in User
    this.setParameters= function (parameter, variable) {
        if (variable!==null && variable!==undefined)
            switch (parameter) {
                case 'status':
                    this.status = variable;
                    break;
                case 'creation_date':
                    this.creation_date = new Date(variable);
                    break;
                case 'email':
                    this.email = variable;
                    break;
                case 'password':
                    this.password = variable;
                    break;
                case 'company':
                    this.company = variable;
                    break;
                case 'description':
                    this.description = variable;
                    break;
                case 'identification_card':
                    this.identification_card = variable;
                    break;
                case 'name':
                    this.name = variable;
                    break;
                case 'profile':
                    this.profile = variable;
                    break;
            }
    }
}

module.exports = User;

