'use strict'

var db = require('../db');
var config = require('../config');
const response = require('../network/responses');
const ObjectId = require('mongodb').ObjectID;

// This function calls the functions in charge of extracting the data 
function getAllData(req, res) {
    let company = req.middlewareParameters.company;
    let overall_promise = new Promise((resolve, reject) => {resolve ('start')})
    overall_promise.then(
             result =>{
               return _getModules(company)
             },error=>{
                console.log(error)
                return  new Promise.reject(error)
             }
        ).then(
            result =>{
                return _getData(result, company)
            },error=>{
                console.log(error)
                return  new Promise.reject(error)
             }
        ).then(
            result => {
                return response.success(req, res, result)
            }, reason => {
                return response.errorMessage(req, res, reason);
        });

}

// This function extracts the existing modules from the database into an array
function _getModules(company) {
    let DB_modules = db.get().db(company).collection(config.getCollModules());
    const modules = new Promise((resolve, reject) => {
        DB_modules.aggregate().toArray(function (err,result) {
            return (err) ? reject ({message:"Request error."}) : resolve(result);
        });
    });

    return modules;
}

// This function generates the data structure asynchronously
async function _getData(modules, company) {    
    const groupBy = (key, array) =>
    array.reduce((objectsByKeyValue, obj) => {
      const value = obj[key];
      objectsByKeyValue[value] = (objectsByKeyValue[value] || []).concat(obj);
      return objectsByKeyValue;
    }, {});

    var data = await Promise.all(modules.map(async function(modules) {
        var stations = await Promise.all(modules.childrens.map(function(station_id) {
            let DB_stations = db.get().db(company).collection(config.getCollStations());
            let search = {_id: station_id._id}; 
            const station = new Promise((resolve, reject) => {
                DB_stations.aggregate([{ $match : search }]).toArray(async function (err,result) {
                    if(err){
                        reject ({message:"Request error."});
                    }else{                 
                        var substations = await Promise.all(result[0].childrens.map(function(substation_id) {
                            let coll_substations = (modules.type === 'chemical_monitoring') ? config.getCollSubstationsCM() 
                            : (modules.type === 'laboratory_data') ? config.getCollSubstationsLD() : config.getCollSubstationsS();
                            let DB_substations = db.get().db(company).collection(coll_substations);
                            let search = {_id: substation_id._id}; 
                            const substation = new Promise((resolve, reject) => {
                                DB_substations.aggregate([{ $match : search }]).toArray(async function (err,result) {
                                    if(err){
                                        reject ({message:"Request error."});
                                    }else{
                                        let type = result[0].type
                                        var containers = await Promise.all(result[0].childrens.map(function(container_id) {
                                            let coll_containers = (modules.type === 'chemical_monitoring') ? config.getCollContainersCM() 
                                            : (modules.type === 'laboratory_data') ? config.getCollContainersLD() : config.getCollContainersS();
                                            let DB_containers = db.get().db(company).collection(coll_containers);
                                            let search = {_id: container_id._id}; 
                                            const container = new Promise((resolve, reject) => {
                                                DB_containers.aggregate([{ $match : search }]).toArray(async function (err,result) {
                                                    if(err){
                                                        reject ({message:"Request error."});
                                                    }else{   
                                                        if (result[0].childrens !== undefined){
                                                            var childrens = await Promise.all(result[0].childrens.map(function(children_id) {
                                                                let coll_childrens = "";
                                                                switch(modules.type) {
                                                                    case 'chemical_monitoring':
                                                                        (type === 'station_plants') ? coll_childrens = config.getCollOperatingConditionsCM()
                                                                            : coll_childrens = config.getCollWellsCM()
                                                                        break;
                                                                    /*
                                                                    case 'laboratory_data':
                                                                        this.id_parent = new ObjectId(variable);
                                                                        break;
                                                                    case 'supplying':
                                                                        this.id_parent = new ObjectId(variable);
                                                                        break;
                                                                    */
                                                                } 
                                                                
                                                                let DB_childrens = db.get().db(company).collection(coll_childrens);
                                                                let search = {_id: children_id._id}; 
                                                                
                                                                const child = new Promise((resolve, reject) => {
                                                                    DB_childrens.aggregate([{ $match : search }]).toArray(function (err, result) {
                                                                        if(err){
                                                                            return reject ({message:"Request error."});
                                                                        }else{                                                                        
                                                                            return resolve(result[0]);
                                                                        }
                                                                    });
                                                                });
                                                                return child                                    
                                                            }))
                                                            result[0].childrens = childrens
                                                            //result[0].childrens = groupBy('type', childrens)
                                                        } 
                                                        resolve(result[0])                                                       
                                                    }
                                                });
                                            });
                                            return container
                
                                        }))
                                        if (modules.type !== 'laboratory_data') result[0].childrens = groupBy('chemical', containers)
                                        resolve(result[0]);
                                    }
                                });
                            });
                            return substation
                        }))
                        result[0].childrens = groupBy('type', substations)
                        resolve(result[0]);
                    }
                });
            });
            return station
        }))
        modules.childrens = groupBy('block', stations)
        return modules        
    }))
    return data
}

module.exports = {
    getAllData,
};