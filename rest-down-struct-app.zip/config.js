'use strict'

const jwt = require('jsonwebtoken');

module.exports={

    getJWT:function() {
        return 'kjdfsgkhjk5hjsdhdskjfh435h3k4j5hkj34h5khjsdfgj9953jk5hkj';
    },
    getUserID:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).userID;
    },
    getCompanyDB:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).companyDB;
    },
    getExpirationTime:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).expirationTime;
    },

    getPrt:function(){
        return 40000;
    },

    getDataBase:function() {
        return 'GeneralAdministration';
    },
    getCollUsers:function(){
        return 'users';
    },

    getCollModules:function(){
        return 'modules';
    },
    getCollStations:function(){
        return 'stations';
    },
    getCollSubstationsCM:function(){
        return 'substationsCM';
    },
    getCollSubstationsLD:function(){
        return 'substationsLD';
    },
    getCollSubstationsSP:function(){
        return 'substationsSP';
    },
    getCollContainersCM:function(){
        return 'containersCM';
    },
    getCollContainersLD:function(){
        return 'containersLD';
    },
    getCollContainersSP:function(){
        return 'containersSP';
    },
    getCollObservations:function(){
        return 'observations';
    },
    getCollOperatingConditions:function(){
        return 'operatingConditions';
    }, 
    getCollWellsCM:function(){
        return 'wellsCM';
    },
};