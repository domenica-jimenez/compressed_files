'use strict'

const db = require('./db');
const app = require('./app');
const config = require('./config');

const port =  config.getPrt(); 

db.connect('mongodb://mongoadmin:mongopass@13.58.149.80:45000/admin', function(err) {
    if (err) {
        return console.log(err)
    } else {
        console.log("Conexion establecida...");
        app.listen(port, function(){
        console.log("API inicializada sobre el puerto "+port);
        })
    }
});
