'use strict'

const express = require('express');
const bodyParser = require('body-parser');
const app = express();

const route = require('./network/routes');
const cors = require('cors');

app.use(bodyParser.json({limit: '30mb'}));
app.use(bodyParser.urlencoded({limit: '30mb', extended: true}));

app.use(bodyParser.json())

app.use((req, res, next)=>{
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH');
    res.header('Allow', 'GET, POST, PUT, PATCH');
    next();
});

app.use(cors());

app.use('/', route);
app.get('/estado', function(req, res) {
    return res.status(200).send('Controlador API funcionando correctamente')
});

module.exports = app;