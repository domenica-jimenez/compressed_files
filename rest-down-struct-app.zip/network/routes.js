var express = require('express');
var structure = require('../controllers/structure');
var middleware = require('../middleware/authorization');
var router = express.Router();

// Route to obtain the data of the general structure
router.get('/structure', middleware.verification, structure.getAllData);

module.exports = router;