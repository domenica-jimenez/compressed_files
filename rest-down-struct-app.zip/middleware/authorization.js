'use strict'

var config = require('../config');
var db = require('../db');
var response = ('../network/response');

// This function extracts the user parameters, company and expiration time
// of the header token to verify that the user's status is active
exports.verification = function(req, res, next) {

    let date = new Date()

    if (req.headers.authorization === undefined) return response.incompleteData(req, res);

    let user = config.getUserID(req.headers);
    let company = config.getCompanyDB(req.headers);
    let expiration_time = config.getExpirationTime(req.headers);
    let current_time = date.getTime()/1000;

    if (current_time > expiration_time) console.log('Token caducad.');

    if (user === undefined || user === null || company === undefined || company === null) 
        return response.incompleteData(req, res);

    // After the _searchUser() function is executed
    // Verify that the user's status is active
    _searchUser(user).then(
        result=>{
            // 0 = Active, 1 = Inactive, 2 = Blocked
            if (result.status !== 0) return response.unauthorized(req, res);
            req.middlewareParameters = {
                email: result.email,
                company: company
            };
            next();
        },
        error=>{
            return response.error(req, res);
        }
    )

};

// The _searchUser() function receives as a parameter user of type string that can be email or ID 
// Verify that the user exists in the database
function _searchUser(user){
    
    let DB = db.get().db(config.getDataBase()).collection(config.getCollUsers());
    let search = {$or: [{identification_card: user},{email: user}]};

    let filter = {
        _id:0,
        name:1,
        email:1,
        status:1
    }

    const userDB = new Promise((resolve, reject) => {
        DB.aggregate([{ $match : search }, {$project: filter}]).toArray (function (err,result) {
            if (err){
                reject ("Error en la busqueda");
            }else {
                if (result.length == 0) reject('No existe el usuario');
                resolve(result[0]);
            }
        });
    });
    return userDB;
}
