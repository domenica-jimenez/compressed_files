var ObjectId = require('mongodb').ObjectID;

function Photo(){

        this._id = new ObjectId(),
        this.photo = "",
        this.name =  "",
        this.date = new Date(),
        this.author =  ""

    // Setter for data changes in Photo
    this.setParameters= function (parameter, variable) {
        if(variable!==null && variable!==undefined)
            switch (parameter) {
                case 'photo':
                    this.photo = variable;
                    break;
                case 'name':
                    this.name = variable;
                    break;
                case 'date':
                    this.date = new Date(variable);
                    break;
                case 'author':
                    this.author = variable;
                    break;
            }
    }
}

module.exports = Photo;

