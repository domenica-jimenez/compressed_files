var ObjectId = require('mongodb').ObjectID;

function Well(){

        this._id = new ObjectId(),
        this.id_parent = new ObjectId(),
        this.status = 0,
        this.name = "",
        this.criticality =  "Alta",
        this.recommended_dose = 25,
        this.real_dose = 0,
        this.production_data  = [],
        this.childrens_observations = []

    // Setter for data changes in Well
    this.setParameters= function (parameter, variable) {
        if(variable!==null && variable!==undefined)
            switch (parameter) {
                case 'id_parent':
                    this.id_parent = variable;
                    break;
                case 'status':
                    this.status = variable;
                    break;
                case 'name':
                    this.name = variable;
                    break;
                case 'criticality':
                    this.criticality = variable;
                    break;
                case 'recommended_dose':
                    this.recommended_dose = variable;
                    break;
                case 'real_dose':
                    this.real_dose = variable;
                    break;
                case 'production_data':
                    this.production_data = variable;
                    break;
            }
    }
}

module.exports = Well;

