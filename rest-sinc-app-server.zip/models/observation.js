var ObjectId = require('mongodb').ObjectID;

function Observation(){

        this._id = new ObjectId(),
        this.id_parent = new ObjectId(),
        this.status = 0,
        this.process = "",
        this.group =  "",
        this.subgroup = "",
        this.date = new Date(),
        this.description = "",
        this.other =  "",
        this.author =  "",
        this.photo = new ObjectId(),
        this.type = "",
        this.subtype = ""

    // Setter for data changes in Observation
    this.setParameters= function (parameter, variable) {
        if(variable!==null && variable!==undefined)
            switch (parameter) {
                case 'id_parent':
                    this.id_parent = new ObjectId(variable);
                    break;
                case 'status':
                    this.status = variable;
                    break;
                case 'process':
                    this.process = variable;
                    break;
                case 'group':
                    this.group = variable;
                    break;
                case 'subgroup':
                    this.subgroup = variable;
                    break;
                case 'date':
                    this.date = new Date(variable);
                    break;
                case 'description':
                    this.description = variable;
                    break;
                case 'other':
                    this.other = variable;
                    break;
                case 'author':
                    this.author = variable;
                    break;
                case 'photo':
                    this.photo = new ObjectId(variable);
                    break;
                case 'type':
                    this.type = variable;
                    break;
                case 'subtype':
                    this.subtype = variable;
                    break;
            }
    }
}

module.exports = Observation;

