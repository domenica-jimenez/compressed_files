var ObjectId = require('mongodb').ObjectID;

function OperatingCondition(){

        this._id = new ObjectId(),
        this.id_parent = new ObjectId(),
        this.status = 0,
        this.type = "Otro",
        this.name = "",
        this.description = "",
        this.recommended_dose =  90,
        this.real_dose = 0,
        this.capacity = "barriles",
        this.entry_pressure = "psi",
        this.discharge_pressure = "psi",
        this.entry_temperature = "*F",
        this.discharge_temperature = "*F",
        this.author = "",
        this.childrens_observations = []

    // Setter for data changes in OperatingCondition
    this.setParameters= function (parameter, variable) {
        if(variable!==null && variable!==undefined)
            switch (parameter) {
                case 'id_parent':
                    this.id_parent = new ObjectId(variable);
                    break;
                case 'status':
                    this.status = variable;
                    break;
                case 'type':
                    this.type = variable;
                    break;
                case 'name':
                    this.name = variable;
                    break;
                case 'description':
                    this.description = variable;
                    break;
                case 'recommended_dose':
                    this.recommended_dose = variable;
                    break;
                case 'real_dose':
                    this.real_dose = variable;
                    break;
                case 'capacity':
                    this.capacity = variable;
                    break;
                case 'entry_pressure':
                    this.entry_pressure = variable;
                    break;
                case 'discharge_pressure':
                    this.discharge_pressure = variable;
                    break;
                case 'entry_temperature':
                    this.entry_temperature = variable;
                    break;
                case 'discharge_temperature':
                    this.discharge_temperature = variable;
                    break;
                case 'author':
                    this.author = variable;
                    break;
            }
    }
}

module.exports = OperatingCondition;

