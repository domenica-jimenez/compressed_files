var ObjectId = require('mongodb').ObjectID;

function OperatingCondition(){

        this._id = new ObjectId(),
        this.id_parent = new ObjectId(),
        this.status = 0,
        this.type = "Otro",
        this.name = "",
        this.description = "",
        this.recommendedDose =  90,
        this.realDose = 0,
        this.capacity = "barriles",
        this.entryPressure = "psi",
        this.dischargePressure = "psi",
        this.entryTemperature = "*F",
        this.dischargeTemperature = "*F",
        this.author = "",
        this.childrens_observations = []

    // Setter for data changes in OperatingCondition
    this.setParameters= function (parameter, variable) {
        if(variable!==null && variable!==undefined)
            switch (parameter) {
                case 'id_parent':
                    this.id_parent = new ObjectId(variable);
                    break;
                case 'status':
                    this.status = variable;
                    break;
                case 'type':
                    this.type = variable;
                    break;
                case 'name':
                    this.name = variable;
                    break;
                case 'description':
                    this.description = variable;
                    break;
                case 'recommendedDose':
                    this.recommendedDose = variable;
                    break;
                case 'realDose':
                    this.realDose = variable;
                    break;
                case 'capacity':
                    this.capacity = variable;
                    break;
                case 'entryPressure':
                    this.entryPressure = variable;
                    break;
                case 'dischargePressure':
                    this.dischargePressure = variable;
                    break;
                case 'entryTemperature':
                    this.entryTemperature = variable;
                    break;
                case 'dischargeTemperature':
                    this.dischargeTemperature = variable;
                    break;
                case 'author':
                    this.author = variable;
                    break;
            }
    }
}

module.exports = OperatingCondition;

