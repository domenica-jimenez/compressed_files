var ObjectId = require('mongodb').ObjectID;

function Container(){

        this._id = new ObjectId(),
        this.id_parent = new ObjectId(),
        this.status = 0,
        this.container_identifier = "",
        this.name = "",
        this.description =  "",
        this.dilutionFactor = "1% químico",
        this.measuredStock = "",
        this.expectedConsumption = "85 galones",
        this.measuredConsumption =  "",
        this.author = "",
        this.chemical = "",
        this.childrens = [],
        this.childrens_observations =  [],

    // Setter for data changes in Container
    this.setParameters= function (parameter, variable) {
        if(variable!==null && variable!==undefined)
            switch (parameter) {
                case 'id_parent':
                    this.id_parent = variable;
                    break;
                case 'status':
                    this.status = variable;
                    break;
                case 'container_identifier':
                    this.container_identifier = variable;
                    break;
                case 'name':
                    this.name = variable;
                    break;
                case 'description':
                    this.description = variable;
                    break;
                case 'dilutionFactor':
                    this.dilutionFactor = variable;
                    break;
                case 'measuredStock':
                    this.measuredStock = variable;
                    break;
                case 'expectedConsumption':
                    this.expectedConsumption = variable;
                    break;
                case 'measuredConsumption':
                    this.measuredConsumption = variable;
                    break;
                case 'author':
                    this.author = variable;
                    break;
                case 'chemical':
                        this.chemical = variable;
                        break;
            }
    }
}

module.exports = Container;

