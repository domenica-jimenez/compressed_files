var ObjectId = require('mongodb').ObjectID;

function Container(){

        this._id = new ObjectId(),
        this.id_parent = new ObjectId(),
        this.status = 0,
        this.container_identifier = "",
        this.name = "",
        this.description =  "",
        this.dilution_factor = "1% químico",
        this.measured_stock = "",
        this.expected_consumption = "85 galones",
        this.measured_consumption =  "",
        this.author = "",
        this.chemical = "",
        this.childrens = [],
        this.childrens_observations =  [],

    // Setter for data changes in Container
    this.setParameters= function (parameter, variable) {
        if(variable!==null && variable!==undefined)
            switch (parameter) {
                case 'id_parent':
                    this.id_parent = variable;
                    break;
                case 'status':
                    this.status = variable;
                    break;
                case 'container_identifier':
                    this.container_identifier = variable;
                    break;
                case 'name':
                    this.name = variable;
                    break;
                case 'description':
                    this.description = variable;
                    break;
                case 'dilution_factor':
                    this.dilution_factor = variable;
                    break;
                case 'measured_stock':
                    this.measured_stock = variable;
                    break;
                case 'expected_consumption':
                    this.expected_consumption = variable;
                    break;
                case 'measured_consumption':
                    this.measured_consumption = variable;
                    break;
                case 'author':
                    this.author = variable;
                    break;
                case 'chemical':
                        this.chemical = variable;
                        break;
            }
    }
}

module.exports = Container;

