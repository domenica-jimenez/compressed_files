'use strict'

const db = require('../db');
const db_files = require('../db_files');
const config = require('../config');
const response = require('../network/responses');
const ObjectId = require('mongodb').ObjectID;
const Photo = require('../models/photo');
const Observation = require('../models/observation');

// Create a Observation and a Photo
function createObservation(req, res){

    if (!req.body.date || !req.body.photo || !req.body.name || !req.body.id_parent) 
        return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;

    let DB_FILES = db_files.get().db(company).collection(config.getCollObservations());
    let DB = db.get().db(company).collection(config.getCollObservations());

    let photo = new Photo();
    photo.setParameters('photo', req.body.photo);
    photo.setParameters('name', req.body.name);
    photo.setParameters('date', req.body.date);
    photo.setParameters('author', email);

    

    DB_FILES.insertOne(photo, (err, file_inserted) => {
        if (err) return response.error(req, res);

        let observation = new Observation();
        observation.setParameters('id_parent', req.body.id_parent);
        observation.setParameters('process', req.body.process);
        observation.setParameters('group', req.body.group);
        observation.setParameters('subgroup', req.body.subgroup);
        observation.setParameters('date', req.body.date);
        observation.setParameters('description', req.body.description);
        observation.setParameters('other', req.body.other);
        observation.setParameters('author', email);
        observation.setParameters('photo', file_inserted.insertedId);
        observation.setParameters('type', req.body.type);
        observation.setParameters('subtype', req.body.subtype);

        DB.insertOne(observation, (err, observation_inserted) => {
            return (err) ? response.error(req, res) : response.successMessage(req, res);           
        })
    })
}

// Dynamic update of Observation data
function updateObservation(req, res){

    if (!req.body._id && !req.body.date) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;

    let search_observation = {_id: new ObjectId(req.body._id)};
    let update_observation = {
        date: new Date(req.body.date),
        author: email
    }

    if (req.body.process) update_observation.process = req.body.process;
    if (req.body.group) update_observation.group = req.body.group;
    if (req.body.subgroup) update_observation.subgroup = req.body.subgroup;
    if (req.body.description) update_observation.description = req.body.description;
    if (req.body.other) update_observation.other = req.body.other;
    if (req.body.type) update_observation.type = req.body.type;
    if (req.body.subtype) update_observation.subtype = req.body.subtype;

    let DB_FILES = db_files.get().db(company).collection(config.getCollObservations());
    let DB = db.get().db(company).collection(config.getCollObservations());

    DB.findOneAndUpdate(search_observation, {$set: update_observation}, (err, result) => {
        if (err){
            return response.error(req, res);
        }else {
            if (result.value == null) return response.notFound(req, res);

            let search_photo = {_id: new ObjectId(result.value.photo)};
            let update_photo = {
                date: new Date(req.body.date),
                author: email
            }

            if (req.body.photo) update_photo.photo = req.body.photo;
            if (req.body.name) update_photo.name = req.body.name;

            DB_FILES.findOneAndUpdate(search_photo, {$set: update_photo}, (err,result) => {
                return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res);
            })
        }
    })

}

// Show the Observation data in one object and the Photo linked to that Observation in another. 
function showObservation(req, res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_observation ={_id: new ObjectId(req.body._id)};
    let filter_observation = {projection:{_id: 0, status: 0, id_parent: 0}};

    let DB_FILES = db_files.get().db(company).collection(config.getCollObservations());
    let DB = db.get().db(company).collection(config.getCollObservations());

    DB.find(search_observation, filter_observation).toArray((err,result) => {
        if (err){
            return response.error(req, res);
        }else {
            if (result.length == 0) return response.notFound(req, res); 
            
            let search_photo ={_id: new ObjectId(result[0].photo)};

            DB_FILES.find(search_photo).toArray((err, result_photo) => {
                if (err){
                    return response.error(req, res);
                }else {
                    if(result_photo.length == 0){
                        return response.notFound(req, res);
                    }else{
                        result[1] = {
                            name: result_photo[0].name,
                            photo: result_photo[0].photo
                        }
                        return response.success(req, res, result)
                    }
                }
            })
        }
    })
}

// Show all Observations (array of objects) of a specified id_parent 
function showObservations(req, res){

    if (!req.body.id_parent) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_observation ={status: 0, id_parent: new ObjectId(req.body.id_parent)};
    let filtro_observation = {projection:{_id: 0, status: 0, photo: 0}};

    let DB = db.get().db(company).collection(config.getCollObservations());

    DB.find(search_observation, filtro_observation).toArray((err,result) => {
        return (err) ? response.error(req, res) : (result.length == 0) ? response.notFound(req, res) : response.success(req, res, result)
    })
}

// Change the status of an Observation to 1 (Inactive) 
function deleteObservation(req,res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_observation = {_id: new ObjectId(req.body._id)};
    let update_observation = {
        status: 1
    }

    let DB = db.get().db(company).collection(config.getCollObservations());

    DB.findOneAndUpdate(search_observation, {$set: update_observation}, (err, result) => {
        return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res)
    })
}

module.exports = {
    createObservation,
    updateObservation,
    showObservation,
    showObservations,
    deleteObservation
};

