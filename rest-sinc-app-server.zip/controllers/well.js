'use strict'

const db = require('../db');
const config = require('../config');
const response = require('../network/responses');
const ObjectId = require('mongodb').ObjectID;
const OperatingCondition = require('../models/operatingCondition');

// Create a Well
function createWell(req, res){

    if (!req.body.name || !req.body.real_dose || !req.body.id_parent) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;

    let DB_PARENT = db.get().db(company).collection(config.getCollContainersCM());
    let DB = db.get().db(company).collection(config.getCollOperatingConditions());

    let operating_condition = new OperatingCondition();
    operating_condition.setParameters('id_parent', req.body.id_parent);
    operating_condition.setParameters('type', req.body.type);
    operating_condition.setParameters('name', req.body.name);
    operating_condition.setParameters('description', req.body.description);
    operating_condition.setParameters('real_dose', req.body.real_dose);
    operating_condition.setParameters('author', email);

    DB.insertOne(operating_condition, (err, operating_condition_inserted) => {
        if (err) {
            response.error(req, res)
        }else {
            let search_parent = {_id: new ObjectId(req.body.id_parent)};
            let agregate_parent = {childrens: {_id: new ObjectId(operating_condition_inserted.insertedId)}}

            DB_PARENT.findOneAndUpdate(search_parent, {$push: agregate_parent}, (err, result) => {
                if (err){
                    return response.error(req, res);
                }else {
                    if(result.length == 0){
                        return response.notFound(req, res);
                    }else{
                        return response.successMessage(req, res);
                    }
                }
            })
            
        } 
    })
}

// Dynamic update of Well data
function updateWell(req, res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;

    let search_operating_condition = {_id: new ObjectId(req.body._id)};
    let update_operating_condition = {
        author: email
    }

    if (req.body.name) update_operating_condition.name = req.body.name;
    if (req.body.description) update_operating_condition.description = req.body.description;
    if (req.body.type) update_operating_condition.type = req.body.type;
    if (req.body.real_dose) update_operating_condition.real_dose = req.body.real_dose;

    let DB = db.get().db(company).collection(config.getCollOperatingConditions());

    DB.findOneAndUpdate(search_operating_condition, {$set: update_operating_condition}, (err, result) => {
        return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res);
    })

}

// Show the Well data 
function showWell(req, res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_operating_condition ={_id: new ObjectId(req.body._id)};
    let filter_operating_condition = {projection:{_id: 0, status: 0, id_parent: 0}};

    let DB = db.get().db(company).collection(config.getCollOperatingConditions());

    DB.find(search_operating_condition, filter_operating_condition).toArray((err,result) => {
        return (err) ? response.error(req, res) : (result.length == 0) ? response.notFound(req, res) 
        : response.success(req, res, result);
    })
}

// Change the status of a Well to 1 (Inactive) 
function deleteWell(req,res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_operating_condition = {_id: new ObjectId(req.body._id)};
    let update_operating_condition = {
        status: 1
    }

    let DB = db.get().db(company).collection(config.getCollOperatingConditions());

    DB.findOneAndUpdate(search_operating_condition, {$set: update_operating_condition}, (err, result) => {
        return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res)
    })
}

module.exports = {
    createWell,
    updateWell,
    showWell,
    deleteWell
};