'use strict'

const db = require('../db');
const config = require('../config');
const response = require('../network/responses');
const ObjectId = require('mongodb').ObjectID;
const OperatingCondition = require('../models/operatingCondition');

// Create a OperatingCondition
function createOperatingCondition(req, res){

    if (!req.body.name || !req.body.realDose || !req.body.id_parent) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;

    let DB = db.get().db(company).collection(config.getCollOperatingConditionsCM());

    let operating_condition = new OperatingCondition();
    operating_condition.setParameters('id_parent', req.body.id_parent);
    operating_condition.setParameters('type', req.body.type);
    operating_condition.setParameters('name', req.body.name);
    operating_condition.setParameters('description', req.body.description);
    operating_condition.setParameters('realDose', req.body.realDose);
    operating_condition.setParameters('author', email);

    DB.insertOne(operating_condition, (err) => {
        return (err) ? response.error(req, res) : response.successMessage(req, res);
    })
}

// Dynamic update of OperatingCondition data
function updateOperatingCondition(req, res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;

    let search_operating_condition = {_id: new ObjectId(req.body._id)};
    let update_operating_condition = {
        author: email
    }

    if (req.body.name) update_operating_condition.name = req.body.name;
    if (req.body.description) update_operating_condition.description = req.body.description;
    if (req.body.type) update_operating_condition.type = req.body.type;
    if (req.body.realDose) update_operating_condition.realDose = req.body.realDose;

    let DB = db.get().db(company).collection(config.getCollOperatingConditionsCM());

    DB.findOneAndUpdate(search_operating_condition, {$set: update_operating_condition}, (err, result) => {
        return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res);
    })

}

// Show the OperatingCondition data 
function showOperatingCondition(req, res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_operating_condition ={_id: new ObjectId(req.body._id)};
    let filter_operating_condition = {projection:{_id: 0, status: 0, id_parent: 0}};

    let DB = db.get().db(company).collection(config.getCollOperatingConditionsCM());

    DB.find(search_operating_condition, filter_operating_condition).toArray((err,result) => {
        return (err) ? response.error(req, res) : (result.length == 0) ? response.notFound(req, res) 
        : response.success(req, res, result);
    })
}

// Change the status of a OperatingCondition to 1 (Inactive) 
function deleteOperatingCondition(req,res){

    if (!req.body._id) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_operating_condition = {_id: new ObjectId(req.body._id)};
    let update_operating_condition = {
        status: 1
    }

    let DB = db.get().db(company).collection(config.getCollOperatingConditionsCM());

    DB.findOneAndUpdate(search_operating_condition, {$set: update_operating_condition}, (err, result) => {
        return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res)
    })
}

module.exports = {
    createOperatingCondition,
    updateOperatingCondition,
    showOperatingCondition,
    deleteOperatingCondition
};