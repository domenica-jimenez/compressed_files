'use strict'

const db = require('../db');
const config = require('../config');
const response = require('../network/responses');
const ObjectId = require('mongodb').ObjectID;
const Container = require('../models/container');

// Create a Container
function createContainer(req, res){

    if (!req.body.measured_stock || !req.body.measured_consumption || !req.body.name 
        || !req.body.container_identifier || !req.body.chemical || !req.body.id_parent 
        || !req.body.substation_identifier) 
        return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;
    let coll_containers = "";
    let coll_substation = "";

    switch(req.body.container_identifier){
        case 'c-cm':
            coll_containers = config.getCollContainersCM()
            break;
        case 'c-ld':
            coll_containers = config.getCollContainersLD()
            break;
        case 'c-sp':
            coll_containers = config.getCollContainersSP()
            break;
    }

    switch(req.body.substation_identifier){
        case 's-cm':
            coll_substation = config.getCollSubstationsCM()
            break;
        case 's-ld':
            coll_substation = config.getCollSubstationsLD()
            break;
        case 's-sp':
            coll_substation = config.getCollSubstationsSP()
            break;
    }

    let DB_PARENT = db.get().db(company).collection(coll_substation);
    let DB = db.get().db(company).collection(coll_containers);

    let container = new Container();
    container.setParameters('id_parent', req.body.id_parent);
    container.setParameters('container_identifier', req.body.container_identifier);
    container.setParameters('name', req.body.name);
    container.setParameters('description', req.body.description);
    container.setParameters('dilution_factor', req.body.dilution_factor);
    container.setParameters('measured_stock', req.body.measured_stock);
    container.setParameters('expected_consumption', req.body.expected_consumption);
    container.setParameters('measured_consumption', req.body.measured_consumption);
    container.setParameters('author', email);
    container.setParameters('chemical', req.body.chemical);

    DB.insertOne(container, (err, container_inserted) => {
        if (err) {
            return response.error(req, res)
        }else {
            let search_parent = {_id: new ObjectId(req.body.id_parent)};
                let agregate_parent = {childrens: {_id: new ObjectId(container_inserted.insertedId)}}

                DB_PARENT.findOneAndUpdate(search_parent, {$push: agregate_parent}, (err, result) => {
                    if (err){
                        return response.error(req, res);
                    }else {
                        if(result.length == 0){
                            return response.notFound(req, res);
                        }else{
                            return response.successMessage(req, res);
                        }
                    }
                })
        } 
    })
}

// Dynamic update of Container data
function updateContainer(req, res){

    if (!req.body._id && !req.body.type) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let email = req.middlewareParameters.email;

    let search_container = {_id: new ObjectId(req.body._id)};
    let update_container = {
        author: email
    }

    if (req.body.name) search_container.name = req.body.name;
    if (req.body.description) search_container.description = req.body.description;
    if (req.body.measured_stock) search_container.measured_stock = req.body.measured_stock;
    if (req.body.measured_consumption) search_container.measured_consumption = req.body.measured_consumption;
    if (req.body.chemical) search_container.chemical = req.body.chemical;

    let coll_containers = (req.body.type === 0) ? config.getCollContainersCM() 
    : (req.body.type === 1) ? config.getCollContainersLD() : config.getCollContainersS();

    let DB = db.get().db(company).collection(coll_containers);

    DB.findOneAndUpdate(search_container, {$set: update_container}, (err, result) => {
        return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res);
    })

}

// Show the Container data 
function showContainer(req, res){

    if (!req.body._id && !req.body.container_identifier) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;
    let coll_containers = "";

    switch(req.body.container_identifier){
        case 'c-cm':
            coll_containers = config.getCollContainersCM()
            break;
        case 'c-ld':
            coll_containers = config.getCollContainersLD()
            break;
        case 'c-sp':
            coll_containers = config.getCollContainersSP()
            break;
    }
    
    let search_container ={_id: new ObjectId(req.body._id)};
    let filter_container = {projection:{_id: 0, status: 0, id_parent: 0}};

    let DB = db.get().db(company).collection(coll_containers);

    DB.find(search_container, filter_container).toArray((err,result) => {
        return (err) ? response.error(req, res) : (result.length == 0) ? response.notFound(req, res) 
        : response.success(req, res, result);
    })
}

// Show all Containers (array of objects) of a specified id_parent 
function showContainers(req, res){

    if (!req.body.id_parent && !req.body.type) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_container ={status: 0, id_parent: new ObjectId(req.body.id_parent)};
    let filter_container = {projection:{_id: 0, status: 0, name: 1, description: 1}};

    let coll_containers = (req.body.type === 0) ? config.getCollContainersCM() 
    : (req.body.type === 1) ? config.getCollContainersLD() : config.getCollContainersS();

    let DB = db.get().db(company).collection(coll_containers);

    DB.find(search_container, filter_container).toArray((err,result) => {
        return (err) ? response.error(req, res) : (result.length == 0) ? response.notFound(req, res) : response.success(req, res, result)
    })
}

// Change the status of a Container to 1 (Inactive) 
function deleteContainer(req,res){

    if (!req.body._id && !req.body.type) return response.incompleteData(req, res);

    let company = req.middlewareParameters.company;

    let search_container = {_id: new ObjectId(req.body._id)};
    let update_container = {
        status: 1
    }

    let coll_containers = (req.body.type === 0) ? config.getCollContainersCM() 
    : (req.body.type === 1) ? config.getCollContainersLD() : config.getCollContainersS();

    let DB = db.get().db(company).collection(coll_containers);

    DB.findOneAndUpdate(search_container, {$set: update_container}, (err, result) => {
        return (err) ? response.error(req, res) : (result.value == null) ? response.notFound(req, res) : response.successMessage(req, res)
    })
}

module.exports = {
    createContainer,
    updateContainer,
    showContainer,
    showContainers,
    deleteContainer
};

