'use strict'

var express = require('express');
var observation = require('../controllers/observation');
var operatingCondition = require('../controllers/operatingCondition');
var well = require('../controllers/well');
var container = require('../controllers/container');
var middleware = require('../middleware/authorization');
var router = express.Router();

// Routes for Observations 
router.post('/createObservation', middleware.verification, observation.createObservation);
router.put('/updateObservation', middleware.verification, observation.updateObservation);
router.post('/showObservation', middleware.verification, observation.showObservation);
router.post('/showObservations', middleware.verification, observation.showObservations);
router.patch('/deleteObservation', middleware.verification, observation.deleteObservation);

// Routes for OperatingConditions 
router.post('/createOpConditions', middleware.verification, operatingCondition.createOperatingCondition);
router.put('/updateOpConditions', middleware.verification, operatingCondition.updateOperatingCondition);
router.post('/showOpConditions', middleware.verification, operatingCondition.showOperatingCondition);
router.patch('/deleteOpConditions', middleware.verification, operatingCondition.deleteOperatingCondition);

// Routes for Well 
router.post('/createWell', middleware.verification, well.createWell);
router.put('/updateWell', middleware.verification, well.updateWell);
router.post('/showWell', middleware.verification, well.showWell);
router.patch('/deleteWell', middleware.verification, well.deleteWell);

// Routes for Containers
//router.post('/createOpConditions', middleware.verification, operatingCondition.createOperatingCondition);
//router.put('/updateOpConditions', middleware.verification, operatingCondition.updateOperatingCondition);
router.post('/showContainer', middleware.verification, container.showContainer);
//router.get('/showOpConditions', middleware.verification, operatingCondition.showOperatingCondition);
//router.patch('/deleteOpConditions', middleware.verification, operatingCondition.deleteOperatingCondition);

module.exports = router;