'use strict'

var express = require('express');
var observation = require('../controllers/observation');
var operatingCondition = require('../controllers/operatingCondition');
var middleware = require('../middleware/authorization');
var router = express.Router();

// Routes for Observations 
router.post('/createObservation', middleware.verification, observation.createObservation);
router.put('/updateObservation', middleware.verification, observation.updateObservation);
router.get('/showObservation', middleware.verification, observation.showObservation);
router.get('/showObservations', middleware.verification, observation.showObservations);
router.patch('/deleteObservation', middleware.verification, observation.deleteObservation);

// Routes for OperatingConditions 
router.post('/createOpConditions', middleware.verification, operatingCondition.createOperatingCondition);
router.put('/updateOpConditions', middleware.verification, operatingCondition.updateOperatingCondition);
router.get('/showOpConditions', middleware.verification, operatingCondition.showOperatingCondition);
router.patch('/deleteOpConditions', middleware.verification, operatingCondition.deleteOperatingCondition);

module.exports = router;