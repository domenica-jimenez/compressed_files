exports.success = function(req, res, data){
    res.status(200).send(data);
}

exports.successMessage = function(req, res){
    res.status(200).send({
        status: 200,
        error: 'Data created/update successfully.'
    });
}

exports.incompleteData = function(req, res){
    res.status(400).send({
        status: 400,
        error: 'Incomplete parameters.'
    });
} 

exports.notFound = function(req, res){
    res.status(400).send({
        status: 400,
        error: 'Data not found.'
    });
}

exports.unauthorized = function(req, res){
    res.status(401).send({
        status: 401,
        error: 'Unauthorized user.'
    });
}


exports.error = function(req, res){
    res.status(500).send({
        status: 500,
        error: 'Request error.'
    });
}


