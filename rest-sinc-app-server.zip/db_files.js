'use strict'

var MongoClient = require('mongodb').MongoClient

var state = {
    db2: null,
}

exports.connect = function(url, done) {
    if (state.db2) return done()

    MongoClient.connect(url, function(err, db2) {
        if (err) return done(err)
        state.db2 = db2
        done()
    })
}

exports.get = function() {
    return state.db2
}

exports.close = (done) => {
    done = done || function() {};  
    if (state.db2) {
        state.db2.close((err, result) => {
            state.db2 = null;
            state.mode = null;
            done(err);
        })
    }
}
