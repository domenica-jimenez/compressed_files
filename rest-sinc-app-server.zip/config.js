'use strict'

const jwt = require('jsonwebtoken');

module.exports={

    getJWT:function() {
        return 'kjdfsgkhjk5hjsdhdskjfh435h3k4j5hkj34h5khjsdfgj9953jk5hkj';
    },
    getUserID:function(headers) {
        let token = headers.authorization.split(' ')[0];
        return jwt.decode(token, this.JWT_SECRET).userID;
    },
    getCompanyDB:function(headers) {
        let token = headers.authorization.split(' ')[0];
        return jwt.decode(token, this.JWT_SECRET).companyDB;
    },
    getExpirationTime:function(headers) {
        let token = headers.authorization.split(' ')[0];
        return jwt.decode(token, this.JWT_SECRET).expirationTime;
    },

    getPrt:function(){
        return 40200;
    },

    getDataBase:function() {
        return 'GeneralAdministration';
    },
    getCollUsers:function(){
        return 'users';
    },
    getCollCompanies:function(){
        return 'companies';
    },
    getCollContainersCM:function(){
        return 'containersCM';
    },
    getCollContainersLD:function(){
        return 'containersLD';
    },
    getCollContainersS:function(){
        return 'containersS';
    },
    getCollObservations:function(){
        return 'observations';
    },
    getCollOperatingConditionsCM:function(){
        return 'operatingConditionsCM';
    },    

};
